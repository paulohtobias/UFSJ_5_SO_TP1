generic c project
